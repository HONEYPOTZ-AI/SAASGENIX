# SaaSgenix Terraform Modules

This repository contains Terraform modules for deploying various SaaS components.

## Modules Included
- auth0
- postgresql
- redis
- prometheus
- grafana
- sentry
- vault
- okta

## Usage
Each module contains a `main.tf` file. You can use these modules in your Terraform configuration by referencing the appropriate folder.

Example:
module "auth0" {
  source = "./auth0"
}
